//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  // Plugin registrations are generated automatically by `flutter pub get`.
}
